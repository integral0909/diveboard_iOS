//
//  OSBlurSlideMenu.h
//  OSBlurSlideMenuDemo
//
//  Created by Alexandr Stepanov on 12.05.14.
//  Copyright (c) 2014 StartApp. All rights reserved.
//

#ifndef OSBlurSlideMenuDemo_OSBlurSlideMenu_h
#define OSBlurSlideMenuDemo_OSBlurSlideMenu_h

#import "OSBlurSlideMenuController.h"
#import "OSBlurredView.h"

#endif
