Change Log
==========

Version 2.0.4 *(2014-09-18)*
----------------------------
* Change: Better URL for iOS 7.1 and 8 support

Version 2.0.3 *(2014-05-14)*
----------------------------
 * New: Make alert content customizable
