//
//  UITextField+VTCustomFont.h
//  ValetTAB
//
//  Created by Abid Khan on 09/01/14.
//  Copyright (c) 2013 ValetTAB LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (VTCustomFont)

@property (nonatomic, copy) NSString *fontName;

@end
