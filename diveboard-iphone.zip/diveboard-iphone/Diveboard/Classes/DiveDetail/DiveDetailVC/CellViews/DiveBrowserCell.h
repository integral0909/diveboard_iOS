//
//  DiveBrowserCell.h
//  Diveboard
//
//  Created by Vladimir Popov on 11/3/14.
//  Copyright (c) 2014 Vladimir Popov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DiveDetailBaseCell.h"
@interface DiveBrowserCell : DiveDetailBaseCell

- (IBAction)onBrowser:(id)sender;
@end
