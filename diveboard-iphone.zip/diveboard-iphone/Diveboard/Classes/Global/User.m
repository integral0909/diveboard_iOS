//
//  User.m
//  Diveboard
//
//  Created by Vladimir Popov on 1/7/14.
//  Copyright (c) 2014 Vladimir Popov. All rights reserved.
//

#import "User.h"

@implementation User

@synthesize _id, trip_name, image, _countryName, _date, _dives, _fullpermalink,
            _location, _nickname, _picture, _picture_large, _picture_small, _public_nb_dives,
            _qualifications, _shaken_id, _total_nb_dives, _totalExtDives, _unitPreferences,
            _userGears, _vanity_url;
@end
