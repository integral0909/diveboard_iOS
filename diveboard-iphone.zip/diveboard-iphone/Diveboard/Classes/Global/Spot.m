//
//  Spot.m
//  Diveboard
//
//  Created by Vladimir Popov on 1/6/14.
//  Copyright (c) 2014 Vladimir Popov. All rights reserved.
//

#import "Spot.h"

@implementation Spot

@synthesize _id, _cname, _countryCode, _countryFlagBig, _countryFlagSmall, _countryId, _countryName,
            _lat, _lng, _location, _locationId, _locationName, _name,
            _privateUserId, _regionId, _shakenId, _zoom;
@end
